﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BabyWireShark
{
    public partial class Form1 : Form
    {
        private string selectedPcapPath;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            // Allow ONLY .pcap and .pcapng
            dialog.Filter = "PCAP Files (*.pcap)|*.pcap";
            dialog.Title = "Select a PCAP File";

            if (dialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = dialog.FileName;

                // Store selected path somewhere useful (field-level variable)
                selectedPcapPath = filePath;

                // Optional: display it in a label or textbox

                MessageBox.Show("File selected:\n" + filePath);

                if (selectedPcapPath == null)
                {
                    MessageBox.Show("Choose a file first.");
                    return;
                }

                FileStream pcapRead = new FileStream(selectedPcapPath, FileMode.Open, FileAccess.Read);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
            "Basic Functionality:\n" +
            "- Open a .pcap file using the 'Open File' button.\n" +
            "- On file open, the backend will parse each packet.\n" +
            "- Human readable results will be converted from the .pcap hex data.\n",
            "Program Help",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information
        );
        }
    }
}
